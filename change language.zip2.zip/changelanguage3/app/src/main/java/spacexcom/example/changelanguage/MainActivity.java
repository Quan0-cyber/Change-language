package spacexcom.example.changelanguage;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    EditText edtcoefficientA;
    EditText edtcoefficientB;
    TextView txtResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        addview();
        
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void setLocale(String languageCode) {
        Locale locale = new Locale(languageCode);
        Locale.setDefault(locale);

        // Tạo một đối tượng Configuration mới với ngôn ngữ mới
        Configuration config = new Configuration();
        config.setLocale(locale);

        // Áp dụng cấu hình mới với Context.createConfigurationContext
        Context context = getApplicationContext();
        context = context.createConfigurationContext(config);

        // Cập nhật resources với context mới
        getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());

        // Tải lại Activity để áp dụng thay đổi
        recreate();
    }
    private void addview() {
        edtcoefficientA = findViewById(R.id.edtcoefficientA);
        edtcoefficientB = findViewById(R.id.edtCoefficientB);
        txtResult = findViewById(R.id.txresult);

    }

    public void do_solution(View view) {
        //để lấy giá trị hệ số a:

        String hsa = edtcoefficientA.getText().toString();
        double a = Double.parseDouble(hsa);

        //để lấy giá trị hệ số b:
        double b = Double.parseDouble(edtcoefficientB.getText().toString());
        // tiến hành giải phương trình
        if (a == 0 && b == 0) {
            txtResult.setText("Phương trình vô số nghiệm");
        } else if (a == 0 && b != 0) {
            txtResult.setText(" No solution!");

        } else {
            txtResult.setText("x=" + (-b / a));
        }

    }
    public void do_next(View view) {
    }

    public void do_exit(View view) {
    }
    public void change_English(View view) {
        setLocale("en");
    }

    public void change_Vietnamese(View view) {
        setLocale("vi");
    }
}